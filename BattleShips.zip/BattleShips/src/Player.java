import java.util.ArrayList;


public class Player 
{
	private String name;
	
	ArrayList<Ship> playerShips = new ArrayList<Ship>();
	
	public Player(String name) 
	{
		
		// TODO Auto-generated constructor stub
	}

}
